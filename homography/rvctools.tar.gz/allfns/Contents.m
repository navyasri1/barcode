% VGG User Interface Library
%
% GUI's
%   vgg_gui_F            - Visualizes epipolar geometry between two views
%   vgg_gui_H            - Visualizes a homography between two views
